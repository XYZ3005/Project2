﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;

namespace BLL
{
    public class BusinessLogicLayer
    {
        DataAccessLayer dal = new DataAccessLayer();
        
        public int InsertSuburb(Suburb s)
        {
            return dal.InsertSuburb(s);
        }

        public DataTable GetSuburb()
        {
            return dal.GetSuburb();
        }
        public int InsertAgency(Agency a)
        {
            return dal.InsertAgency(a);
        }

        public DataTable GetAgency()
        {
            return dal.GetAgency();
        }
        public int DeleteAgency(Agency a)
        {
            return dal.DeleteAgency(a);
        }
        public DataTable GetCity()
        {
            return dal.GetCity();
        }
    }
}
