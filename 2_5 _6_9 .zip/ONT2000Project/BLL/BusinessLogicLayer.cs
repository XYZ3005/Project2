﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;

namespace BLL
{
    public class BusinessLogicLayer
    {
        DataAccessLayer dal = new DataAccessLayer();
        
        public int InsertSuburb(Suburb s)
        {
            return dal.InsertSuburb(s);
        }
        public int InsertAgency(Agency a)
        {
            return dal.InsertAgency(a);
        }
        public int InsertProperty(Property pro)
        {
            return dal.InsertProperty(pro);
        }
        public int InsertPropertyAgent(PropertyAgent proA)
        {
            return dal.InsertPropertyAgent(proA);
        }
        public DataTable GetAgency()
        {
            return dal.GetAgency();
        }
        public DataTable GetProperty()
        {
            return dal.GetProperty();
        }
        public DataTable GetCity()
        {
            return dal.GetCity();
        }
        public DataTable GetSuburb()
        {
            return dal.GetSuburb();
        }
        public DataTable GetPropertyType()
        {
            return dal.GetPropertyType();
        }
        public DataTable GetAgent()
        {
            return dal.GetAgent();
        }
        public DataTable GetPropertyAgent()
        {
            return dal.GetPropertyAgent();
        }
        public int DeleteAgency(Agency a)
        {
            return dal.DeleteAgency(a);
        }
        public int DeleteProperty(Property pro)
        {
            return dal.DeleteProperty(pro);
        }
        public int UpdateProperty(Property pro)
        {
            return dal.UpdateProperty(pro);
        }
        public int UpdatePropertyAgent(PropertyAgent proA)
        {
            return dal.UpdatePropertyAgent(proA);
        }
        
    }
}
