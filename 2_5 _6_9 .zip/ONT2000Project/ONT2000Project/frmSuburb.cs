﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;


namespace ONT2000Project
{
    public partial class frmSuburb : Form
    {
        public frmSuburb()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Suburb s = new Suburb();
            bool validate = false;

            if (string.IsNullOrEmpty(txtSubDesc.Text))
            {
                errDesc.SetError(txtSubDesc, "Please enter Suburb Description");
                validate = false;
            }
            else
            {
                validate = true;
            }
            if (string.IsNullOrEmpty(txtPostCode.Text))
            {
                errCode.SetError(txtPostCode, "Please enter Post Code");
                validate = false;
            }
            else
            {
                validate = true;
            }

            s.SuburbDescription = txtSubDesc.Text;
            s.PostalCode = txtPostCode.Text;
            s.CityID = int.Parse(cmbCity.SelectedValue.ToString());

            if (validate)
            {
                int x = bll.InsertSuburb(s);
                if (x > 0)
                {
                    MessageBox.Show(x + "Added.");
                }
            }
            else
            {

            }
        }

        private void dgvSuburb_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSuburb.SelectedRows.Count > 0)
            {
                txtSubDesc.Text = dgvSuburb.SelectedRows[0].Cells["SuburbDescription"].Value.ToString();
                txtPostCode.Text = dgvSuburb.SelectedRows[0].Cells["PostalCode"].Value.ToString();
                cmbCity.Text = dgvSuburb.SelectedRows[0].Cells["SuburbID"].Value.ToString();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvSuburb.DataSource = bll.GetSuburb();
        }

        private void frmSuburb_Load(object sender, EventArgs e)
        {
            cmbCity.DataSource = bll.GetCity();
            cmbCity.DisplayMember = "CityDescription";
            cmbCity.ValueMember = "CityID";
        }

        private void agencyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAgency f = new frmAgency();
            f.Show();
            this.Hide();
        }

        private void propertyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProperty f = new frmProperty();
            f.Show();
            this.Hide();
        }

        private void propertyAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPropertyAgent f = new frmPropertyAgent();
            f.Show();
            this.Hide();
        }
    }
}
