﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace ONT2000Project
{
    public partial class frmPropertyAgent : Form
    {
        public frmPropertyAgent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        int PropertyAgentID;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            PropertyAgent proA = new PropertyAgent();
           
            proA.PropertyID = int.Parse(cmbProperty.SelectedValue.ToString());
            proA.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            proA.Date = DateTime.Parse(dtpDate.Value.ToString());

            int x = bll.InsertPropertyAgent(proA);
            if (x > 0)
            {
                MessageBox.Show(x + "Added.");
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            PropertyAgent proA = new PropertyAgent();

            proA.PropertyAgentID = PropertyAgentID;
            proA.PropertyID = int.Parse(cmbProperty.SelectedValue.ToString());
            proA.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            proA.Date = DateTime.Parse(dtpDate.Text);

            int x = bll.UpdatePropertyAgent(proA);
            if (x > 0)
            {
                MessageBox.Show(x + "Updated.");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvPropertyAgent.DataSource = bll.GetPropertyAgent();
        }

        private void frmPropertyAgent_Load(object sender, EventArgs e)
        {
            cmbProperty.DataSource = bll.GetProperty();
            cmbProperty.DisplayMember = "Description";
            cmbProperty.ValueMember = "PropertyID";

            cmbAgent.DataSource = bll.GetAgent();
            cmbAgent.DisplayMember = "Fullname";
            cmbAgent.ValueMember = "AgentID";
        }

        private void dgvPropertyAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPropertyAgent.SelectedRows.Count > 0)
            {
                PropertyAgentID = int.Parse(dgvPropertyAgent.SelectedRows[0].Cells["PropertyAgentID"].Value.ToString());
                cmbProperty.Text = dgvPropertyAgent.SelectedRows[0].Cells["PropertyID"].Value.ToString();
                cmbAgent.Text = dgvPropertyAgent.SelectedRows[0].Cells["AgentID"].Value.ToString();
                dtpDate.Text = dgvPropertyAgent.SelectedRows[0].Cells["Date"].Value.ToString();
            }
        }

        private void agencyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAgency f = new frmAgency();
            f.Show();
            this.Hide();
        }

        private void propertyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProperty f = new frmProperty();
            f.Show();
            this.Hide();
        }

        private void suburbToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuburb f = new frmSuburb();
            f.Show();
            this.Hide();
        }
    }
}
