﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.IO;

namespace ONT2000Project
{
    public partial class frmProperty : Form
    {
       
        public frmProperty()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        int PropertyID;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Property pro = new Property();
            bool validate = false;

            Image img = pictureBox1.Image;
            byte[] arr;
            ImageConverter converter = new ImageConverter();
            arr = (byte[])converter.ConvertTo(img,typeof(byte[]));

            if (string.IsNullOrEmpty(txtProDesc.Text))
            {
                errDesc.SetError(txtProDesc, "Please enter Property Description");
                validate = false;
            }
            else
            {
                validate = true;
            }
            if (string.IsNullOrEmpty(txtPrice.Text))
            {
                errPrice.SetError(txtPrice, "Please enter Price");
                validate = false;
            }
            else
            {
                validate = true;
            }
            if (string.IsNullOrEmpty(txtStatus.Text))
            {
                errStatus.SetError(txtStatus, "Please enter Status");
                validate = false;
            }
            else
            {
                validate = true;
            }

            pro.Description = txtProDesc.Text;
            pro.Price = int.Parse(txtPrice.Text);
            pro.Image = arr;
            pro.PropertyTypeID = int.Parse(cmbProType.SelectedValue.ToString());
            pro.Status = txtStatus.Text;
            pro.SurbubID = int.Parse(cmbSurbub.SelectedValue.ToString());

            if (validate)
            {
                int x = bll.InsertProperty(pro);
                if (x > 0)
                {
                    MessageBox.Show(x + "Added.");
                }
            }
            else
            {

            }
        }

        byte[] ConvertImageToBytes(Image img)
        {
            using(MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        public Image ConvertByteArrayToImage(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            {
                return Image.FromStream(ms);
            }
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(ofd.FileName);
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvProperty.DataSource = bll.GetProperty();
        }

        private void dgvProperty_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable dt = dgvProperty.DataSource as DataTable;
            if (dgvProperty.SelectedRows.Count > 0)
            { DataRow row = dt.Rows[e.RowIndex];
                txtProDesc.Text = dgvProperty.SelectedRows[0].Cells["Description"].Value.ToString();
                txtPrice.Text = dgvProperty.SelectedRows[0].Cells["Price"].Value.ToString();
                pictureBox1.Image = ConvertByteArrayToImage((byte[])row["Image"]);
                cmbProType.Text = dgvProperty.SelectedRows[0].Cells["PropertyTypeID"].Value.ToString();
                txtStatus.Text = dgvProperty.SelectedRows[0].Cells["Status"].Value.ToString();
                cmbProType.Text = dgvProperty.SelectedRows[0].Cells["PropertyTypeID"].Value.ToString();
                PropertyID = int.Parse(dgvProperty.SelectedRows[0].Cells["PropertyID"].Value.ToString());
            }
        }

        private void frmProperty_Load(object sender, EventArgs e)
        {
            cmbSurbub.DataSource = bll.GetSuburb();
            cmbSurbub.DisplayMember = "SuburbDescription";
            cmbSurbub.ValueMember = "SurbubID";

            cmbProType.DataSource = bll.GetPropertyType();
            cmbProType.DisplayMember = "PropertyTypeDescription";
            cmbProType.ValueMember = "PropertyTypeID";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Property pro = new Property();
            pro.PropertyID = PropertyID;

            int x = bll.DeleteProperty(pro);
            if (x > 0)
            {
                MessageBox.Show(x + "Deleted.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Property pro = new Property();
            pro.PropertyID = PropertyID;
            pro.PropertyTypeID = int.Parse(cmbProType.SelectedValue.ToString());
            pro.Price = int.Parse(txtPrice.Text);
            pro.Status = txtStatus.Text;

            int x = bll.UpdateProperty(pro);
            if (x > 0)
            {
                MessageBox.Show(x + "Updated.");
            }
        }

        private void agencyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAgency f = new frmAgency();
            f.Show();
            this.Hide();
        }

        private void suburbToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuburb f = new frmSuburb();
            f.Show();
            this.Hide();
        }

        private void propertyAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPropertyAgent f = new frmPropertyAgent();
            f.Show();
            this.Hide();
        }
    }
}
