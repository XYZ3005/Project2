﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace ONT2000Project
{
    public partial class frmAgency : Form
    {
        public frmAgency()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        int AgencyID;
        private void btnAdd_Click(object sender, EventArgs e)
        {

            Agency a = new Agency();
            bool validate = false;
            

            if (string.IsNullOrEmpty(txtName.Text))
            {
                errName.SetError(txtName, "Please enter Agency Name");
                validate = false;
            }
            else
            {
                validate = true;
            }

            a.AgencyName = txtName.Text;
            a.SuburbID = int.Parse(cmbSurbub.SelectedValue.ToString());
         
            if (validate)
            {
                int x = bll.InsertAgency(a);
                if (x > 0)
                {
                    MessageBox.Show(x + "Added.");
                }
            }
            else
            {

            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAgency.DataSource = bll.GetAgency();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Agency a = new Agency();
            a.AgencyID = AgencyID;

            int x = bll.DeleteAgency(a);
            if (x > 0)
            {
                MessageBox.Show(x + "Deleted.");
            }
        }

        private void frmAgency_Load(object sender, EventArgs e)
        {
            cmbSurbub.DataSource = bll.GetSuburb();
            cmbSurbub.DisplayMember = "SuburbDescription";
            cmbSurbub.ValueMember = "SurbubID";
        }

        private void dgvAgency_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvAgency.SelectedRows.Count > 0)
            {
                cmbSurbub.Text = dgvAgency.SelectedRows[0].Cells["SurbubID"].Value.ToString();
                txtName.Text = dgvAgency.SelectedRows[0].Cells["AgencyName"].Value.ToString();
                AgencyID = int.Parse(dgvAgency.SelectedRows[0].Cells["AgencyID"].Value.ToString());
            }
        }

        private void suburbToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuburb f = new frmSuburb();
            f.Show();
            this.Hide();
        }

        private void propertyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProperty f = new frmProperty();
            f.Show();
            this.Hide();
        }

        private void propertyAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPropertyAgent f = new frmPropertyAgent();
            f.Show();
            this.Hide();
            
        }
    }
}
