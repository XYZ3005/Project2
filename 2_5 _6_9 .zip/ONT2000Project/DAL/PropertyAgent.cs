﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class PropertyAgent
    {
        public int PropertyAgentID { get; set; }
        public int PropertyID { get; set; }
        public int AgentID { get; set; }
        public DateTime Date { get; set; }
    }
}
