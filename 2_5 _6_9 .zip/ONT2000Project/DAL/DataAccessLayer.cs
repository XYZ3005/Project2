﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace DAL
{
    public class DataAccessLayer
    {

        static string connString = "Data Source=LAPTOP-TEB5S4NB\\SQLEXPRESS01;Initial Catalog=Prac;Integrated Security=True";
        SqlConnection dbConn = new SqlConnection(connString);
        SqlCommand dbComm;
        SqlDataAdapter dbAdapter;
        DataTable dt;

        public int InsertSuburb(Suburb s)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertSurbub", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@SuburbDescription", s.SuburbDescription);
            dbComm.Parameters.AddWithValue("@PostalCode", s.PostalCode);
            dbComm.Parameters.AddWithValue("@CityID", s.CityID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int InsertAgency(Agency a)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@AgencyName", a.AgencyName);
            dbComm.Parameters.AddWithValue("@SurbubID", a.SuburbID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;

        }
        public int InsertProperty(Property pro)
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@Description", pro.Description);
            dbComm.Parameters.AddWithValue("@Price", pro.Price);
            dbComm.Parameters.AddWithValue("@Image", pro.Image);
            dbComm.Parameters.AddWithValue("@PropertyTypeID", pro.PropertyTypeID);
            dbComm.Parameters.AddWithValue("@Status", pro.Status);
            dbComm.Parameters.AddWithValue("@SurbubID", pro.SurbubID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;

        }
        public int InsertPropertyAgent(PropertyAgent proA)
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertPropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@PropertyID", proA.PropertyID);
            dbComm.Parameters.AddWithValue("@AgentID", proA.AgentID);
            dbComm.Parameters.AddWithValue("@Date", proA.Date);
       

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;

        }
        public int DeleteAgency(Agency a)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@AgencyID", a.AgencyID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int DeleteProperty(Property pro)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@PropertyID", pro.PropertyID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable GetSuburb()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetSurbub", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetAgency()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetAgency", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetProperty()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetProperty", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetCity()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetCity", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetPropertyType()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetPropertyType", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetAgent()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetAgent", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        public DataTable GetPropertyAgent()
        {
            dbConn.Open();

            dbComm = new SqlCommand("sp_GetPropertyAgent", dbConn);

            dt = new DataTable();

            dbAdapter = new SqlDataAdapter(dbComm);

            dbAdapter.Fill(dt);

            dbConn.Close();
            return dt;
        }
        
        public int UpdateProperty(Property pro)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdateProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@PropertyID", pro.PropertyID);
            dbComm.Parameters.AddWithValue("@PropertyTypeID", pro.PropertyTypeID);
            dbComm.Parameters.AddWithValue("@Price", pro.Price);
            dbComm.Parameters.AddWithValue("@Status", pro.Status);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int UpdatePropertyAgent(PropertyAgent proA)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdatePropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;

            dbComm.Parameters.AddWithValue("@PropertyAgentID", proA.PropertyAgentID);
            dbComm.Parameters.AddWithValue("@PropertyID", proA.PropertyID);
            dbComm.Parameters.AddWithValue("@AgentID", proA.AgentID);
            dbComm.Parameters.AddWithValue("@Date", proA.Date);


            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
    }
  
}
